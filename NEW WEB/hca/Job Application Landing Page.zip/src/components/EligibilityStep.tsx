import React from 'react';
import { FormData } from './ApplicationForm';

interface EligibilityStepProps {
  formData: FormData;
  onNext: (data: Partial<FormData>) => void;
}

export function EligibilityStep({ formData, onNext }: EligibilityStepProps) {
  const [localData, setLocalData] = React.useState({
    citizenship: formData.citizenship,
    hasGreenCard: formData.hasGreenCard,
    hasFelon: formData.hasFelon,
    drugFree: formData.drugFree,
    hasReference: formData.hasReference,
    referenceName: formData.referenceName,
    referencePhone: formData.referencePhone,
    positionType: formData.positionType,
    reasonForApplying: formData.reasonForApplying,
    hasCurrentJob: formData.hasCurrentJob,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext(localData);
  };

  const isValid = 
    localData.citizenship &&
    (localData.citizenship === 'yes' || localData.hasGreenCard) &&
    localData.hasFelon &&
    localData.drugFree &&
    localData.hasReference &&
    (localData.hasReference === 'no' || (localData.referenceName && localData.referencePhone)) &&
    localData.positionType &&
    localData.reasonForApplying &&
    localData.hasCurrentJob;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-red-900 mb-2">Eligibility Questions</h2>
        <p className="text-gray-600">
          We are commencing the interview. Please thoroughly read each question and respond promptly. 
          Ask for clarification if needed.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Citizenship */}
        <div>
          <label className="block text-gray-700 mb-2">
            Are you a U.S. citizen? <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="yes"
                checked={localData.citizenship === 'yes'}
                onChange={(e) => setLocalData({ ...localData, citizenship: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Yes, I am a U.S. citizen</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="no"
                checked={localData.citizenship === 'no'}
                onChange={(e) => setLocalData({ ...localData, citizenship: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>No, I am not a U.S. citizen</span>
            </label>
          </div>
        </div>

        {/* Green Card */}
        {localData.citizenship === 'no' && (
          <div>
            <label className="block text-gray-700 mb-2">
              Do you possess a Green Card? <span className="text-red-500">*</span>
            </label>
            <div className="space-y-2">
              <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  required
                  value="yes"
                  checked={localData.hasGreenCard === 'yes'}
                  onChange={(e) => setLocalData({ ...localData, hasGreenCard: e.target.value })}
                  className="w-4 h-4 text-red-600"
                />
                <span>Yes</span>
              </label>
              <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  required
                  value="no"
                  checked={localData.hasGreenCard === 'no'}
                  onChange={(e) => setLocalData({ ...localData, hasGreenCard: e.target.value })}
                  className="w-4 h-4 text-red-600"
                />
                <span>No</span>
              </label>
            </div>
          </div>
        )}

        {/* Felony */}
        <div>
          <label className="block text-gray-700 mb-2">
            Do you have a felony conviction? <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="no"
                checked={localData.hasFelon === 'no'}
                onChange={(e) => setLocalData({ ...localData, hasFelon: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>No</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="yes"
                checked={localData.hasFelon === 'yes'}
                onChange={(e) => setLocalData({ ...localData, hasFelon: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Yes</span>
            </label>
          </div>
        </div>

        {/* Drug Free */}
        <div>
          <label className="block text-gray-700 mb-2">
            Are you free from hard drug use? <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="yes"
                checked={localData.drugFree === 'yes'}
                onChange={(e) => setLocalData({ ...localData, drugFree: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Yes</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="no"
                checked={localData.drugFree === 'no'}
                onChange={(e) => setLocalData({ ...localData, drugFree: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>No</span>
            </label>
          </div>
        </div>

        {/* Work Reference */}
        <div>
          <label className="block text-gray-700 mb-2">
            Can you provide a work reference? <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="yes"
                checked={localData.hasReference === 'yes'}
                onChange={(e) => setLocalData({ ...localData, hasReference: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Yes</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="no"
                checked={localData.hasReference === 'no'}
                onChange={(e) => setLocalData({ ...localData, hasReference: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>No</span>
            </label>
          </div>
        </div>

        {/* Reference Details */}
        {localData.hasReference === 'yes' && (
          <div className="space-y-4 bg-red-50 p-4 rounded-lg">
            <div>
              <label className="block text-gray-700 mb-2">
                Reference Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={localData.referenceName}
                onChange={(e) => setLocalData({ ...localData, referenceName: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                placeholder="Enter reference name"
              />
            </div>
            <div>
              <label className="block text-gray-700 mb-2">
                Reference Phone Number <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                required
                value={localData.referencePhone}
                onChange={(e) => setLocalData({ ...localData, referencePhone: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                placeholder="(555) 123-4567"
              />
            </div>
          </div>
        )}

        {/* Position Type */}
        <div>
          <label className="block text-gray-700 mb-2">
            Are you interested in part-time or full-time opportunities? <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="full-time"
                checked={localData.positionType === 'full-time'}
                onChange={(e) => setLocalData({ ...localData, positionType: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Full-time</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="part-time"
                checked={localData.positionType === 'part-time'}
                onChange={(e) => setLocalData({ ...localData, positionType: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Part-time</span>
            </label>
          </div>
        </div>

        {/* Reason for Applying */}
        <div>
          <label className="block text-gray-700 mb-2">
            What are your reasons for applying? <span className="text-red-500">*</span>
          </label>
          <textarea
            required
            value={localData.reasonForApplying}
            onChange={(e) => setLocalData({ ...localData, reasonForApplying: e.target.value })}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 min-h-32"
            placeholder="Please share your motivation for applying to this position..."
          />
        </div>

        {/* Current Job */}
        <div>
          <label className="block text-gray-700 mb-2">
            Do you have a current job? <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="yes"
                checked={localData.hasCurrentJob === 'yes'}
                onChange={(e) => setLocalData({ ...localData, hasCurrentJob: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Yes</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="no"
                checked={localData.hasCurrentJob === 'no'}
                onChange={(e) => setLocalData({ ...localData, hasCurrentJob: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>No</span>
            </label>
          </div>
        </div>

        <button
          type="submit"
          disabled={!isValid}
          className="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-4 rounded-lg hover:from-red-700 hover:to-red-800 transition-all shadow-md hover:shadow-lg disabled:bg-gray-300 disabled:cursor-not-allowed disabled:shadow-none font-medium"
        >
          Continue to Professional Background →
        </button>
      </form>
    </div>
  );
}
