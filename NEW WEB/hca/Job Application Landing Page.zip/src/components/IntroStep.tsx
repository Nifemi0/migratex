import React from 'react';
import { FormData } from './ApplicationForm';
import { Briefcase, Users, Heart, Shield, Award } from 'lucide-react';

interface IntroStepProps {
  formData: FormData;
  onNext: (data: Partial<FormData>) => void;
}

export function IntroStep({ formData, onNext }: IntroStepProps) {
  const [localData, setLocalData] = React.useState({
    fullName: formData.fullName,
    location: formData.location,
    interviewCode: formData.interviewCode,
    canHandleDuties: formData.canHandleDuties,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext(localData);
  };

  const isValid = localData.fullName && localData.location && localData.interviewCode && localData.canHandleDuties;

  return (
    <div className="space-y-8">
      {/* Welcome Message - Hiring Manager Introduction */}
      <div className="bg-gradient-to-br from-red-600 via-red-700 to-red-900 text-white rounded-xl p-8 shadow-xl">
        <div className="max-w-3xl mx-auto text-center space-y-4">
          <div className="inline-block bg-white/20 backdrop-blur-sm rounded-full px-6 py-2 mb-2">
            <p className="text-red-100 text-sm">Interview Session</p>
          </div>
          <h2 className="text-white text-3xl">Welcome to HCA Healthcare</h2>
          <p className="text-lg leading-relaxed text-red-50">
            Hello and welcome to HCA Healthcare. I am <span className="font-semibold text-white">Ferguson Leslie Renee</span>, the Hiring Manager at HCA Healthcare, 
            and I will be conducting your interview today regarding the open position for Data Entry Clerk.
          </p>
        </div>
      </div>

      <div className="text-center">
        <p className="text-gray-700 text-lg max-w-2xl mx-auto">
          Could you please introduce yourself and provide your location and interview code?
        </p>
      </div>

      {/* Company Values */}
      <div className="bg-red-50 rounded-lg p-6 space-y-4">
        <h3 className="text-red-900">Our Five Core Principles</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="flex items-start gap-3">
            <Users className="w-5 h-5 text-red-600 flex-shrink-0 mt-1" />
            <div>
              <p className="text-gray-900">Client Focus</p>
              <p className="text-gray-600">Building strong partnerships</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Heart className="w-5 h-5 text-red-600 flex-shrink-0 mt-1" />
            <div>
              <p className="text-gray-900">For the Individual</p>
              <p className="text-gray-600">Caring for each person</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Users className="w-5 h-5 text-red-600 flex-shrink-0 mt-1" />
            <div>
              <p className="text-gray-900">Teamwork</p>
              <p className="text-gray-600">Collaboration & support</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-red-600 flex-shrink-0 mt-1" />
            <div>
              <p className="text-gray-900">Responsible Citizenship</p>
              <p className="text-gray-600">Community commitment</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Award className="w-5 h-5 text-red-600 flex-shrink-0 mt-1" />
            <div>
              <p className="text-gray-900">Integrity</p>
              <p className="text-gray-600">Honest & ethical conduct</p>
            </div>
          </div>
        </div>
      </div>

      {/* Job Responsibilities */}
      <div className="bg-gray-50 rounded-lg p-6 space-y-4">
        <h3 className="text-gray-900">Primary Job Responsibilities</h3>
        <ul className="space-y-2 text-gray-700">
          <li className="flex items-start gap-2">
            <span className="text-red-600 mt-1">•</span>
            <span>Preparation of Balance sheets (Mini) and account balancing</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-red-600 mt-1">•</span>
            <span>Invoicing recording and proper data analysis of sales records</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-red-600 mt-1">•</span>
            <span>Recording pay slips into accounting database</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-red-600 mt-1">•</span>
            <span>Work with online supervisor on daily logs utilizing Microsoft Office and Accounting software</span>
          </li>
        </ul>

        <div className="bg-white rounded p-4 mt-4">
          <h4 className="text-gray-900 mb-3">What You Can Expect</h4>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-red-600">✓</span>
              <span>Fast-paced environment with measurable deliverables</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-red-600">✓</span>
              <span>Transferable skills development</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-red-600">✓</span>
              <span>Team-oriented, supportive culture</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-red-600">✓</span>
              <span>Professional development opportunities</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-red-600">✓</span>
              <span>Comprehensive medical benefits (health and dental)</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Integrity Notice */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <p className="text-gray-800">
          <strong>Important:</strong> All necessary questions should be given an answer with integrity 
          to uphold a firm acknowledgment.
        </p>
      </div>

      {/* Introduction Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-gray-700 mb-2">
            Full Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            required
            value={localData.fullName}
            onChange={(e) => setLocalData({ ...localData, fullName: e.target.value })}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
            placeholder="Enter your full name"
          />
        </div>

        <div>
          <label className="block text-gray-700 mb-2">
            Location (City, State) <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            required
            value={localData.location}
            onChange={(e) => setLocalData({ ...localData, location: e.target.value })}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
            placeholder="e.g., Nashville, TN"
          />
        </div>

        <div>
          <label className="block text-gray-700 mb-2">
            Interview Code <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            required
            value={localData.interviewCode}
            onChange={(e) => setLocalData({ ...localData, interviewCode: e.target.value })}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
            placeholder="Enter your interview code"
          />
        </div>

        <div>
          <label className="block text-gray-700 mb-2">
            Are you able to handle the job duties if trained? <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="yes"
                checked={localData.canHandleDuties === 'yes'}
                onChange={(e) => setLocalData({ ...localData, canHandleDuties: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Yes, I am able to handle the job duties</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="no"
                checked={localData.canHandleDuties === 'no'}
                onChange={(e) => setLocalData({ ...localData, canHandleDuties: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>No, I need more information</span>
            </label>
          </div>
        </div>

        <button
          type="submit"
          disabled={!isValid}
          className="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-4 rounded-lg hover:from-red-700 hover:to-red-800 transition-all shadow-md hover:shadow-lg disabled:bg-gray-300 disabled:cursor-not-allowed disabled:shadow-none font-medium"
        >
          Begin Interview →
        </button>
      </form>
    </div>
  );
}