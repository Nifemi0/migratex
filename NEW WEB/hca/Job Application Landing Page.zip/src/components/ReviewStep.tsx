import React, { useState } from 'react';
import { FormData } from './ApplicationForm';
import { Loader2 } from 'lucide-react';

interface ReviewStepProps {
  formData: FormData;
  onNext: (data: Partial<FormData>) => void;
}

export function ReviewStep({ formData, onNext }: ReviewStepProps) {
  const [additionalQuestions, setAdditionalQuestions] = useState(formData.additionalQuestions);
  const [isReviewing, setIsReviewing] = useState(false);

  const handleSubmit = () => {
    setIsReviewing(true);
    // Simulate review process
    setTimeout(() => {
      onNext({ additionalQuestions });
    }, 3000);
  };

  if (isReviewing) {
    return (
      <div className="text-center py-12 space-y-6">
        <div className="flex justify-center">
          <Loader2 className="w-16 h-16 text-red-600 animate-spin" />
        </div>
        <div>
          <h2 className="text-red-900 mb-2">Your Interview is Under Review</h2>
          <p className="text-gray-600">
            Please hold on while your conversation is being reviewed by the Head Department to preview and approve your commitment...
          </p>
        </div>
        <div className="bg-red-50 rounded-lg p-6 max-w-md mx-auto">
          <p className="text-gray-700">
            Keep checking for the final decision. This usually takes a few moments.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-red-900 mb-2">Interview Review</h2>
        <p className="text-gray-600">
          You seem like a perfect fit for this position. Please review your information before final submission.
        </p>
      </div>

      {/* Summary */}
      <div className="bg-red-50 rounded-lg p-6 space-y-4">
        <div>
          <h3 className="text-red-900 mb-4">Application Summary</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-gray-600">Name</p>
              <p className="text-gray-900">{formData.fullName}</p>
            </div>
            <div>
              <p className="text-gray-600">Location</p>
              <p className="text-gray-900">{formData.location}</p>
            </div>
            <div>
              <p className="text-gray-600">Position Type</p>
              <p className="text-gray-900 capitalize">{formData.positionType}</p>
            </div>
            <div>
              <p className="text-gray-600">Desired Hourly Rate</p>
              <p className="text-gray-900">${formData.desiredHourlyRate}/hour</p>
            </div>
            <div>
              <p className="text-gray-600">Payment Frequency</p>
              <p className="text-gray-900 capitalize">{formData.paymentFrequency}</p>
            </div>
            <div>
              <p className="text-gray-600">Bank</p>
              <p className="text-gray-900">{formData.bankName}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Additional Questions */}
      <div>
        <label className="block text-gray-700 mb-2">
          Do you have any questions before we forward your application to the company's board of directors for proper review and consideration?
        </label>
        <textarea
          value={additionalQuestions}
          onChange={(e) => setAdditionalQuestions(e.target.value)}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 min-h-32"
          placeholder="Enter any questions or comments (optional)..."
        />
      </div>

      {/* Confirmation */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <p className="text-gray-800">
          <strong>Important:</strong> By submitting this application, you confirm that all information provided is accurate 
          and complete to the best of your knowledge.
        </p>
      </div>

      <button
        onClick={handleSubmit}
        className="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-4 rounded-lg hover:from-red-700 hover:to-red-800 transition-all shadow-md hover:shadow-lg font-medium"
      >
        Submit Application for Review →
      </button>
    </div>
  );
}
