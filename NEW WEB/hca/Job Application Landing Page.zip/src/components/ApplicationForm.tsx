import React, { useState } from 'react';
import { IntroStep } from './IntroStep';
import { EligibilityStep } from './EligibilityStep';
import { ProfessionalStep } from './ProfessionalStep';
import { CompensationStep } from './CompensationStep';
import { ReviewStep } from './ReviewStep';
import { CongratulationsStep } from './CongratulationsStep';
import { ChevronLeft } from 'lucide-react';
import hcaLogo from 'figma:asset/93d49d6379bcc5b4fcbc027a93fba54c52fc7e8f.png';

export interface FormData {
  // Introduction
  fullName: string;
  location: string;
  interviewCode: string;
  
  // Eligibility
  citizenship: string;
  hasGreenCard: string;
  hasFelon: string;
  drugFree: string;
  hasReference: string;
  referenceName: string;
  referencePhone: string;
  positionType: string;
  reasonForApplying: string;
  hasCurrentJob: string;
  canHandleDuties: string;
  
  // Professional
  strengths: string;
  weaknesses: string;
  professionalProfile: string;
  careerObjectives: string;
  understandsRemote: string;
  
  // Compensation
  loyaltyLevel: string;
  desiredHourlyRate: string;
  paymentFrequency: string;
  bankName: string;
  hasCreditCard: string;
  creditCardIssuer: string;
  creditLimit: string;
  hasCreditDebt: string;
  phoneProvider: string;
  phoneType: string;
  
  // Questions
  additionalQuestions: string;
}

export function ApplicationForm() {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    location: '',
    interviewCode: '',
    citizenship: '',
    hasGreenCard: '',
    hasFelon: '',
    drugFree: '',
    hasReference: '',
    referenceName: '',
    referencePhone: '',
    positionType: '',
    reasonForApplying: '',
    hasCurrentJob: '',
    canHandleDuties: '',
    strengths: '',
    weaknesses: '',
    professionalProfile: '',
    careerObjectives: '',
    understandsRemote: '',
    loyaltyLevel: '',
    desiredHourlyRate: '',
    paymentFrequency: '',
    bankName: '',
    hasCreditCard: '',
    creditCardIssuer: '',
    creditLimit: '',
    hasCreditDebt: '',
    phoneProvider: '',
    phoneType: '',
    additionalQuestions: '',
  });

  const steps = [
    { title: 'Welcome', component: IntroStep },
    { title: 'Eligibility', component: EligibilityStep },
    { title: 'Professional Background', component: ProfessionalStep },
    { title: 'Compensation & Details', component: CompensationStep },
    { title: 'Review', component: ReviewStep },
    { title: 'Congratulations', component: CongratulationsStep },
  ];

  const CurrentStepComponent = steps[currentStep].component;

  const handleNext = (data: Partial<FormData>) => {
    setFormData({ ...formData, ...data });
    setCurrentStep(currentStep + 1);
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-t-lg shadow-lg p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-6">
              <img src={hcaLogo} alt="HCA Healthcare" className="h-14 w-auto" />
              <div className="border-l border-gray-300 pl-6">
                <p className="text-gray-900 text-lg">Data Entry Clerk Position</p>
                <p className="text-gray-600">Remote Opportunity</p>
              </div>
            </div>
            {currentStep > 0 && currentStep < steps.length - 1 && (
              <div className="text-gray-500 bg-gray-100 px-4 py-2 rounded-lg">
                Step {currentStep} of {steps.length - 2}
              </div>
            )}
          </div>
          
          {/* Progress Bar */}
          {currentStep < steps.length - 1 && (
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-red-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }}
              />
            </div>
          )}
        </div>

        {/* Form Content */}
        <div className="bg-white rounded-b-lg shadow-lg p-8">
          {currentStep > 0 && currentStep < steps.length - 1 && (
            <button
              onClick={handleBack}
              className="flex items-center gap-2 text-red-600 hover:text-red-700 mb-6 transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
              Back
            </button>
          )}
          
          <CurrentStepComponent
            formData={formData}
            onNext={handleNext}
            onBack={handleBack}
          />
        </div>

        {/* Footer */}
        <div className="text-center mt-8 text-gray-600">
          <p>© 2024 HCA Healthcare. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}