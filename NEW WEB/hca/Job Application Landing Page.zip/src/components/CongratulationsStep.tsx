import React from 'react';
import { FormData } from './ApplicationForm';
import { CheckCircle2, Gift, Calendar, DollarSign, Heart } from 'lucide-react';

interface CongratulationsStepProps {
  formData: FormData;
}

export function CongratulationsStep({ formData }: CongratulationsStepProps) {
  return (
    <div className="space-y-8">
      {/* Success Message */}
      <div className="text-center space-y-4">
        <div className="flex justify-center">
          <CheckCircle2 className="w-24 h-24 text-green-500" />
        </div>
        <div>
          <h2 className="text-green-600 mb-2">Congratulations, {formData.fullName}!</h2>
          <div className="bg-green-50 border border-green-200 rounded-lg p-6 max-w-2xl mx-auto">
            <p className="text-gray-800">
              After careful consideration, we are delighted to inform you that you have <strong>scored 95%</strong> on 
              the questions answered and have qualified for the position.
            </p>
          </div>
        </div>
      </div>

      {/* Position Details */}
      <div className="bg-red-50 rounded-lg p-6 space-y-4">
        <h3 className="text-red-900">Your Position</h3>
        <p className="text-gray-700">
          Our company is offering you the opportunity to work as a <strong>Data Entry Clerk</strong>, leveraging your 
          experience and exceptional communication skills, with the flexibility to work at your convenience.
        </p>
        <p className="text-gray-700">
          We look forward to witnessing your diligence, charisma, and commitment.
        </p>
        
        <div className="bg-white rounded-lg p-4 mt-4">
          <div className="flex items-center gap-3 mb-3">
            <DollarSign className="w-6 h-6 text-green-600" />
            <div>
              <p className="text-gray-900">Hourly Pay Rate</p>
              <p className="text-gray-900">$30.00/hour</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Calendar className="w-6 h-6 text-red-600" />
            <div>
              <p className="text-gray-900">Working Hours</p>
              <p className="text-gray-600">Flexible schedule as understood</p>
            </div>
          </div>
        </div>
      </div>

      {/* Benefits */}
      <div className="bg-white border border-gray-200 rounded-lg p-6 space-y-4">
        <div className="flex items-center gap-3 mb-4">
          <Gift className="w-6 h-6 text-red-600" />
          <h3 className="text-red-900">HCA Healthcare Benefits</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-start gap-3">
            <span className="text-green-500 mt-1">✓</span>
            <div>
              <p className="text-gray-900">401(k) Retirement Account</p>
              <p className="text-gray-600">Secure your future</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-green-500 mt-1">✓</span>
            <div>
              <p className="text-gray-900">Education Assistance</p>
              <p className="text-gray-600">Continuous learning support</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-green-500 mt-1">✓</span>
            <div>
              <p className="text-gray-900">Health & Dental Insurance</p>
              <p className="text-gray-600">Comprehensive coverage</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-green-500 mt-1">✓</span>
            <div>
              <p className="text-gray-900">Life & AD&D Insurance</p>
              <p className="text-gray-600">Protection for you & family</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-green-500 mt-1">✓</span>
            <div>
              <p className="text-gray-900">Employee Wellness Programs</p>
              <p className="text-gray-600">Health & wellbeing focus</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <span className="text-green-500 mt-1">✓</span>
            <div>
              <p className="text-gray-900">Sick Leave, Vacation & Holidays</p>
              <p className="text-gray-600">Generous time off</p>
            </div>
          </div>
          <div className="flex items-start gap-3 md:col-span-2">
            <span className="text-green-500 mt-1">✓</span>
            <div>
              <p className="text-gray-900">Company Discounts</p>
              <p className="text-gray-600">Exclusive employee benefits</p>
            </div>
          </div>
        </div>
      </div>

      {/* Next Steps */}
      <div className="bg-gradient-to-r from-red-600 to-red-800 text-white rounded-lg p-6 text-center space-y-4">
        <Heart className="w-12 h-12 mx-auto" />
        <div>
          <h3 className="mb-2">Welcome to the HCA Healthcare Family!</h3>
          <p className="text-red-100">
            You will receive further instructions via email regarding your onboarding process, training schedule, 
            and first day details.
          </p>
        </div>
        <div className="bg-white/10 backdrop-blur rounded-lg p-4 mt-4">
          <p className="text-red-100">
            Please check your email regularly for important updates and next steps.
          </p>
        </div>
      </div>

      {/* Manager Badge */}
      <div className="text-center space-y-4">
        <p className="text-gray-700">Interview Conducted By:</p>
        <div className="inline-block bg-white border-2 border-red-600 rounded-lg p-6 shadow-lg">
          <div className="text-center space-y-2">
            <div className="w-20 h-20 bg-red-600 rounded-full mx-auto flex items-center justify-center text-white">
              <span>FL</span>
            </div>
            <div>
              <p className="text-gray-900">Ferguson Leslie Renee</p>
              <p className="text-red-600">Hiring Manager</p>
              <p className="text-gray-600">HCA Healthcare</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
