import React from 'react';
import { FormData } from './ApplicationForm';

interface CompensationStepProps {
  formData: FormData;
  onNext: (data: Partial<FormData>) => void;
}

export function CompensationStep({ formData, onNext }: CompensationStepProps) {
  const [localData, setLocalData] = React.useState({
    loyaltyLevel: formData.loyaltyLevel,
    desiredHourlyRate: formData.desiredHourlyRate,
    paymentFrequency: formData.paymentFrequency,
    bankName: formData.bankName,
    hasCreditCard: formData.hasCreditCard,
    creditCardIssuer: formData.creditCardIssuer,
    creditLimit: formData.creditLimit,
    hasCreditDebt: formData.hasCreditDebt,
    phoneProvider: formData.phoneProvider,
    phoneType: formData.phoneType,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext(localData);
  };

  const isValid = 
    localData.loyaltyLevel &&
    localData.desiredHourlyRate &&
    localData.paymentFrequency &&
    localData.bankName &&
    localData.hasCreditCard &&
    (localData.hasCreditCard === 'no' || (localData.creditCardIssuer && localData.creditLimit)) &&
    localData.hasCreditDebt &&
    localData.phoneProvider &&
    localData.phoneType;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-red-900 mb-2">Compensation & Additional Details</h2>
        <p className="text-gray-600">
          Help us understand your expectations and set up your payment information.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Loyalty Level */}
        <div>
          <label className="block text-gray-700 mb-2">
            On a scale of 100%, what is the level of dependence this company can place on your loyalty, diligence, hard work, and sincerity? <span className="text-red-500">*</span>
          </label>
          <div className="flex items-center gap-4">
            <input
              type="range"
              required
              min="0"
              max="100"
              value={localData.loyaltyLevel || 50}
              onChange={(e) => setLocalData({ ...localData, loyaltyLevel: e.target.value })}
              className="flex-1"
            />
            <div className="bg-red-600 text-white px-4 py-2 rounded-lg min-w-[80px] text-center">
              {localData.loyaltyLevel || 50}%
            </div>
          </div>
        </div>

        {/* Desired Hourly Rate */}
        <div>
          <label className="block text-gray-700 mb-2">
            How much do you wish to earn hourly from this remote work? <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">$</span>
            <input
              type="number"
              required
              min="0"
              step="0.01"
              value={localData.desiredHourlyRate}
              onChange={(e) => setLocalData({ ...localData, desiredHourlyRate: e.target.value })}
              className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
              placeholder="0.00"
            />
          </div>
          <p className="text-gray-600 mt-2">Standard rate is $30/hour</p>
        </div>

        {/* Payment Frequency */}
        <div>
          <label className="block text-gray-700 mb-2">
            What is your preference for payment frequency? <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="weekly"
                checked={localData.paymentFrequency === 'weekly'}
                onChange={(e) => setLocalData({ ...localData, paymentFrequency: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Weekly</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="bi-weekly"
                checked={localData.paymentFrequency === 'bi-weekly'}
                onChange={(e) => setLocalData({ ...localData, paymentFrequency: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Bi-weekly</span>
            </label>
          </div>
        </div>

        {/* Bank Name */}
        <div>
          <label className="block text-gray-700 mb-2">
            Could you please provide the name of the bank you operate with? <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            required
            value={localData.bankName}
            onChange={(e) => setLocalData({ ...localData, bankName: e.target.value })}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
            placeholder="e.g., Chase, Bank of America, Wells Fargo"
          />
          <p className="text-gray-600 mt-2">This helps verify compatibility with the company's payment system</p>
        </div>

        {/* Credit Card */}
        <div>
          <label className="block text-gray-700 mb-2">
            Do you possess a credit card? <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="yes"
                checked={localData.hasCreditCard === 'yes'}
                onChange={(e) => setLocalData({ ...localData, hasCreditCard: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Yes</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="no"
                checked={localData.hasCreditCard === 'no'}
                onChange={(e) => setLocalData({ ...localData, hasCreditCard: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>No</span>
            </label>
          </div>
        </div>

        {/* Credit Card Details */}
        {localData.hasCreditCard === 'yes' && (
          <div className="space-y-4 bg-red-50 p-4 rounded-lg">
            <div>
              <label className="block text-gray-700 mb-2">
                Which banking institution issued it? <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={localData.creditCardIssuer}
                onChange={(e) => setLocalData({ ...localData, creditCardIssuer: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                placeholder="e.g., Visa, Mastercard, American Express"
              />
            </div>
            <div>
              <label className="block text-gray-700 mb-2">
                What is your credit limit? <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                <input
                  type="number"
                  required
                  min="0"
                  value={localData.creditLimit}
                  onChange={(e) => setLocalData({ ...localData, creditLimit: e.target.value })}
                  className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                  placeholder="0"
                />
              </div>
            </div>
          </div>
        )}

        {/* Credit Debt */}
        <div>
          <label className="block text-gray-700 mb-2">
            Do you have credit card debt to pay off? <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="yes"
                checked={localData.hasCreditDebt === 'yes'}
                onChange={(e) => setLocalData({ ...localData, hasCreditDebt: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Yes</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="no"
                checked={localData.hasCreditDebt === 'no'}
                onChange={(e) => setLocalData({ ...localData, hasCreditDebt: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>No</span>
            </label>
          </div>
          <p className="text-gray-600 mt-2">We help our employees build up their credit scores</p>
        </div>

        {/* Phone Provider */}
        <div>
          <label className="block text-gray-700 mb-2">
            What phone network service provider do you utilize? <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            required
            value={localData.phoneProvider}
            onChange={(e) => setLocalData({ ...localData, phoneProvider: e.target.value })}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
            placeholder="e.g., Verizon, AT&T, T-Mobile"
          />
        </div>

        {/* Phone Type */}
        <div>
          <label className="block text-gray-700 mb-2">
            Is it a postpaid or prepaid plan? <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="postpaid"
                checked={localData.phoneType === 'postpaid'}
                onChange={(e) => setLocalData({ ...localData, phoneType: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Postpaid</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="prepaid"
                checked={localData.phoneType === 'prepaid'}
                onChange={(e) => setLocalData({ ...localData, phoneType: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Prepaid</span>
            </label>
          </div>
        </div>

        <button
          type="submit"
          disabled={!isValid}
          className="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-4 rounded-lg hover:from-red-700 hover:to-red-800 transition-all shadow-md hover:shadow-lg disabled:bg-gray-300 disabled:cursor-not-allowed disabled:shadow-none font-medium"
        >
          Continue to Review →
        </button>
      </form>
    </div>
  );
}
