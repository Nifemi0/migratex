import React from 'react';
import { FormData } from './ApplicationForm';

interface ProfessionalStepProps {
  formData: FormData;
  onNext: (data: Partial<FormData>) => void;
}

export function ProfessionalStep({ formData, onNext }: ProfessionalStepProps) {
  const [localData, setLocalData] = React.useState({
    strengths: formData.strengths,
    weaknesses: formData.weaknesses,
    professionalProfile: formData.professionalProfile,
    careerObjectives: formData.careerObjectives,
    understandsRemote: formData.understandsRemote,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext(localData);
  };

  const isValid = 
    localData.strengths &&
    localData.weaknesses &&
    localData.professionalProfile &&
    localData.careerObjectives &&
    localData.understandsRemote;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-red-900 mb-2">Professional Background</h2>
        <p className="text-gray-600">
          Tell us about your professional experience and career aspirations.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Strengths */}
        <div>
          <label className="block text-gray-700 mb-2">
            What are your most significant strengths that could impact your performance in this role? <span className="text-red-500">*</span>
          </label>
          <textarea
            required
            value={localData.strengths}
            onChange={(e) => setLocalData({ ...localData, strengths: e.target.value })}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 min-h-32"
            placeholder="Describe your key strengths relevant to this position..."
          />
        </div>

        {/* Weaknesses */}
        <div>
          <label className="block text-gray-700 mb-2">
            What are your weaknesses that could impact your performance in this role? <span className="text-red-500">*</span>
          </label>
          <textarea
            required
            value={localData.weaknesses}
            onChange={(e) => setLocalData({ ...localData, weaknesses: e.target.value })}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 min-h-32"
            placeholder="Be honest about areas where you'd like to improve..."
          />
        </div>

        {/* Professional Profile */}
        <div>
          <label className="block text-gray-700 mb-2">
            How would you describe your professional profile and relevant experience? <span className="text-red-500">*</span>
          </label>
          <textarea
            required
            value={localData.professionalProfile}
            onChange={(e) => setLocalData({ ...localData, professionalProfile: e.target.value })}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 min-h-32"
            placeholder="Share your professional background, skills, and relevant experience..."
          />
        </div>

        {/* Career Objectives */}
        <div>
          <label className="block text-gray-700 mb-2">
            Can you share your long-term career objectives and how this position aligns with your goals? <span className="text-red-500">*</span>
          </label>
          <textarea
            required
            value={localData.careerObjectives}
            onChange={(e) => setLocalData({ ...localData, careerObjectives: e.target.value })}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 min-h-32"
            placeholder="Describe your career goals and how this role fits into your plans..."
          />
        </div>

        {/* Remote Work Understanding */}
        <div>
          <label className="block text-gray-700 mb-2">
            Are you aware that this is a remote position, and you will be required to work from home with minimal supervision? <span className="text-red-500">*</span>
          </label>
          <div className="space-y-2">
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="yes"
                checked={localData.understandsRemote === 'yes'}
                onChange={(e) => setLocalData({ ...localData, understandsRemote: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>Yes, I understand and am comfortable working remotely with minimal supervision</span>
            </label>
            <label className="flex items-center gap-3 p-3 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
              <input
                type="radio"
                required
                value="need-clarification"
                checked={localData.understandsRemote === 'need-clarification'}
                onChange={(e) => setLocalData({ ...localData, understandsRemote: e.target.value })}
                className="w-4 h-4 text-red-600"
              />
              <span>I need more information about the remote work setup</span>
            </label>
          </div>
        </div>

        <button
          type="submit"
          disabled={!isValid}
          className="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-4 rounded-lg hover:from-red-700 hover:to-red-800 transition-all shadow-md hover:shadow-lg disabled:bg-gray-300 disabled:cursor-not-allowed disabled:shadow-none font-medium"
        >
          Continue to Compensation & Details →
        </button>
      </form>
    </div>
  );
}
