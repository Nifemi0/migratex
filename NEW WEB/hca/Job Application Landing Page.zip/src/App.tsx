import React, { useState } from 'react';
import { ApplicationForm } from './components/ApplicationForm';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-rose-100">
      <ApplicationForm />
    </div>
  );
}